'use strict';

const assert = require('assert');
const gameLogic = require('../gameLogic');

let failures = 0;
function report(name, ok){
  console.log((ok ? 'PASS' : 'FAIL') + ': ' + name);
  if (!ok) failures++;
}

function tryTest(name, fn){
  try {
    fn();
  } catch (e) {
    report(name, false);
    console.log(e.stack);
  }
}

tryTest('addPlayer assigns a slot and claims a spawn block', () => {
  const room = gameLogic.makeRoom('TEST');
  const p1 = gameLogic.addPlayer(room, 'p1', 'Alice');
  report('addPlayer assigns a slot and claims a spawn block', p1.slot === 1 && p1.score === 0 && room.ownerGrid[gameLogic.idx(Math.floor(p1.x), Math.floor(p1.y))] === 1);
});

tryTest('room enforces MAX_PLAYERS limit', () => {
  const room = gameLogic.makeRoom('FULL');
  for (let i = 0; i < gameLogic.MAX_PLAYERS; i++) gameLogic.addPlayer(room, 'p' + i, 'N' + i);
  const overflow = gameLogic.addPlayer(room, 'overflow', 'Overflow');
  report('room enforces MAX_PLAYERS limit', overflow === null && room.players.size === gameLogic.MAX_PLAYERS);
});

tryTest('player moving through neutral ground leaves a trail and can loop back to capture territory', () => {
  const room = gameLogic.makeRoom('CAP');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  const startScore = p.score;
  gameLogic.setInput(room, 'p1', 1, 0);
  let now = Date.now();
  for (let i = 0; i < 60; i++){ gameLogic.tick(room, 0.05, now); now += 50; }
  const grewOutward = p.trail.length > 0 || p.score >= startScore;

  gameLogic.setInput(room, 'p1', 0, 1);
  for (let i = 0; i < 20; i++){ gameLogic.tick(room, 0.05, now); now += 50; }
  gameLogic.setInput(room, 'p1', -1, 0);
  for (let i = 0; i < 60; i++){ gameLogic.tick(room, 0.05, now); now += 50; }
  gameLogic.setInput(room, 'p1', 0, -1);
  for (let i = 0; i < 40; i++){ gameLogic.tick(room, 0.05, now); now += 50; }

  report('player moving through neutral ground leaves a trail and can loop back to capture territory', grewOutward && p.score > startScore);
});

tryTest('running into your own trail kills you and clears the trail', () => {
  const room = gameLogic.makeRoom('SELF');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  const homeCx = p.lastCell.cx, homeCy = p.lastCell.cy;

  const trailCx = homeCx + 6, trailCy = homeCy;
  p.trail = [{ cx: trailCx, cy: trailCy }];
  room.trailGrid[gameLogic.idx(trailCx, trailCy)] = p.slot;

  p.x = trailCx + 1.5; p.y = trailCy + 0.5;
  p.lastCell = { cx: trailCx + 1, cy: trailCy };
  gameLogic.setInput(room, 'p1', -1, 0);

  let now = Date.now();
  let diedAtSomePoint = false;
  for (let i = 0; i < 10; i++){
    gameLogic.tick(room, 0.05, now); now += 50;
    if (!p.alive) { diedAtSomePoint = true; break; }
  }
  report('running into your own trail kills you and clears the trail', diedAtSomePoint && p.trail.length === 0);
});

tryTest('cutting an opponent\'s active trail kills them and the trail cells clear', () => {
  const room = gameLogic.makeRoom('CUT');
  const attacker = gameLogic.addPlayer(room, 'a', 'Attacker');
  const victim = gameLogic.addPlayer(room, 'v', 'Victim');
  victim.x = attacker.x + 6; victim.y = attacker.y; victim.lastCell = { cx: Math.floor(victim.x), cy: Math.floor(victim.y) };

  let now = Date.now();
  gameLogic.setInput(room, 'v', 0, 1);
  for (let i = 0; i < 20; i++){ gameLogic.tick(room, 0.05, now); now += 50; }
  assert(victim.trail.length > 0, 'victim should have an active trail before the cut');

  const targetCell = victim.trail[Math.floor(victim.trail.length / 2)];
  attacker.x = targetCell.cx + 0.5;
  attacker.y = targetCell.cy - 3;
  attacker.lastCell = { cx: targetCell.cx, cy: Math.floor(attacker.y) };
  gameLogic.setInput(room, 'a', 0, 1);
  let victimDied = false;
  for (let i = 0; i < 20; i++){
    gameLogic.tick(room, 0.05, now); now += 50;
    if (!victim.alive) { victimDied = true; break; }
  }
  report('cutting an opponent\'s active trail kills them and the trail cells clear', victimDied && victim.trail.length === 0);
});

tryTest('a dead player respawns with a fresh territory block after the delay', () => {
  const room = gameLogic.makeRoom('RESP');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  const now = Date.now();
  gameLogic.killPlayer(room, p, now);
  gameLogic.tick(room, 0.05, now + 100);
  const stillDead = !p.alive;
  gameLogic.tick(room, 0.05, now + 2500);
  report('a dead player respawns with a fresh territory block after the delay', stillDead && p.alive === true && p.score > 0);
});

tryTest('leaving the grid bounds kills the player', () => {
  const room = gameLogic.makeRoom('BOUNDS');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  p.x = 1; p.y = 1; p.lastCell = { cx: 1, cy: 1 };
  gameLogic.setInput(room, 'p1', -1, 0);
  let now = Date.now();
  let died = false;
  for (let i = 0; i < 20; i++){
    gameLogic.tick(room, 0.05, now); now += 50;
    if (!p.alive) { died = true; break; }
  }
  report('leaving the grid bounds kills the player', died);
});

tryTest('removePlayer clears their trail cells and frees their slot', () => {
  const room = gameLogic.makeRoom('LEAVE');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  gameLogic.setInput(room, 'p1', 1, 0);
  let now = Date.now();
  for (let i = 0; i < 20; i++){ gameLogic.tick(room, 0.05, now); now += 50; }
  gameLogic.removePlayer(room, 'p1');
  const trailCellsClear = room.trailGrid.every(v => v === 0);
  const p2 = gameLogic.addPlayer(room, 'p2', 'Bob');
  report('removePlayer clears their trail cells and frees their slot', trailCellsClear && room.players.size === 1 && p2.slot === 1);
});

tryTest('snapshot serializes an owner string matching grid*grid length and includes all players', () => {
  const room = gameLogic.makeRoom('SNAP');
  gameLogic.addPlayer(room, 'p1', 'Alice');
  gameLogic.addPlayer(room, 'p2', 'Bob');
  const snap = gameLogic.snapshot(room);
  report('snapshot serializes an owner string matching grid*grid length and includes all players', snap.owner.length === gameLogic.GRID * gameLogic.GRID && snap.players.length === 2);
});

tryTest('setInput rejects an immediate 180-degree reversal', () => {
  const room = gameLogic.makeRoom('REV');
  const p = gameLogic.addPlayer(room, 'p1', 'Alice');
  gameLogic.setInput(room, 'p1', 1, 0);
  gameLogic.tick(room, 0.05, Date.now());
  gameLogic.setInput(room, 'p1', -1, 0);
  report('setInput rejects an immediate 180-degree reversal', p.nextDir.dx === 1 || (p.dir.dx === 1 && p.nextDir.dx !== -1));
});

process.on('exit', () => {
  console.log(failures === 0 ? 'ALL GAME LOGIC TESTS PASSED' : (failures + ' TEST(S) FAILED'));
  process.exitCode = failures === 0 ? 0 : 1;
});
