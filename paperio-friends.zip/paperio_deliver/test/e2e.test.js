'use strict';

const path = require('path');
const { fork } = require('child_process');

const PORT = 3931;
let failures = 0;

function report(name, ok){
  console.log((ok ? 'PASS' : 'FAIL') + ': ' + name);
  if (!ok) failures++;
}

function wait(ms){ return new Promise(r => setTimeout(r, ms)); }

function waitForMessage(ws, predicate, timeoutMs){
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout waiting for message')), timeoutMs || 3000);
    function onMsg(ev){
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (predicate(msg)){
        clearTimeout(timer);
        ws.removeEventListener('message', onMsg);
        resolve(msg);
      }
    }
    ws.addEventListener('message', onMsg);
  });
}

async function main(){
  const serverProc = fork(path.join(__dirname, '..', 'server.js'), [], {
    env: Object.assign({}, process.env, { PORT: String(PORT) }),
    stdio: ['ignore', 'pipe', 'pipe', 'ipc']
  });

  serverProc.stdout.on('data', () => {});
  serverProc.stderr.on('data', (d) => console.error('SERVER STDERR: ' + d));

  await wait(500);

  try {
    const host = 'ws://127.0.0.1:' + PORT;

    const wsA = new WebSocket(host);
    await new Promise((resolve, reject) => {
      wsA.addEventListener('open', resolve);
      wsA.addEventListener('error', reject);
    });
    wsA.send(JSON.stringify({ t: 'create', name: 'Alice' }));
    const joinedA = await waitForMessage(wsA, m => m.t === 'joined');
    report('host creates a room and receives a 4-character code', typeof joinedA.code === 'string' && joinedA.code.length === 4);

    const wsB = new WebSocket(host);
    await new Promise((resolve, reject) => {
      wsB.addEventListener('open', resolve);
      wsB.addEventListener('error', reject);
    });
    wsB.send(JSON.stringify({ t: 'join', code: joinedA.code, name: 'Bob' }));
    const joinedB = await waitForMessage(wsB, m => m.t === 'joined');
    report('a second client joins the same room by code and gets a different slot', joinedB.code === joinedA.code && joinedB.slot !== joinedA.slot);

    const stateMsg = await waitForMessage(wsA, m => m.t === 'state' && m.players.length === 2);
    report('the server broadcasts tick state to both players once both have joined', stateMsg.players.length === 2 && stateMsg.owner.length === stateMsg.grid * stateMsg.grid);

    const wsC = new WebSocket(host);
    await new Promise((resolve, reject) => {
      wsC.addEventListener('open', resolve);
      wsC.addEventListener('error', reject);
    });
    wsC.send(JSON.stringify({ t: 'join', code: 'ZZZZ', name: 'Ghost' }));
    const errMsg = await waitForMessage(wsC, m => m.t === 'error');
    report('joining a nonexistent room code returns an error instead of crashing the server', typeof errMsg.msg === 'string' && errMsg.msg.length > 0);

    wsA.send(JSON.stringify({ t: 'input', dx: 1, dy: 0 }));
    const moved = await waitForMessage(wsB, m => {
      if (m.t !== 'state') return false;
      const p = m.players.find(x => x.id === joinedA.you);
      return p && p.dir && p.dir.dx === 1;
    });
    report('a player\'s input over the socket is applied server-side and reflected in the broadcast state', !!moved);

    wsA.close(); wsB.close(); wsC.close();
  } catch (e) {
    report('END TO END TEST THREW: ' + e.stack, false);
  } finally {
    serverProc.kill();
  }

  console.log(failures === 0 ? 'ALL E2E TESTS PASSED' : (failures + ' E2E TEST(S) FAILED'));
  process.exit(failures === 0 ? 0 : 1);
}

main();
